uruchamianie:
run.sh katalog > output.txt

katalog zawiera rozwiazanie w formie:
plik wykonywalny Solution.jar, nie przyjmujacy parametrow, generujacy jako rozwiazanie maske jako jednokanalowy obraz i zapisujacy ja w katalogu jako solution.png

w karatalogu run nalezy umiescic:
plik reference.png, zawierajacy rozwiazanie wzrocowe, o tej samej rozdzielczosci co wygenerowane rozwiazanie
