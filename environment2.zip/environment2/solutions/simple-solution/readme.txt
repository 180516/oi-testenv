testowe rozwiazanie:
1. nie przyjmuje parametrow
2. korzysta z dwoch plikow:
- z obrazu zapisanego w katalogu jako input.bsq
- z pliku input-properties.txt, w ktorym w kolejnych liniach znajduja sie: liczba kanalow, szerokosc, wysokosc obrazu wejsciowego
3. generuje wynik w postaci jednokanalowej maski i zapisuje ja do pliku output.png